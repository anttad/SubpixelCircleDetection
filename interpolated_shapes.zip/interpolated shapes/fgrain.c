/*--------------------------- MegaWave2 Module -----------------------------*/
/* mwcommand 
  name = {fgrain}; 
  version = {"1.2"}; 
  author = {"Pascal Monasse, Frederic Guichard, G. Facciolo"}; 
  function = {"Grain filter of an image"}; 
  usage = { 
    'a': [min_area=20]-> pMinArea   "Min area of grains we keep", 
    image_in -> pFloatImageInput    "Input fimage", 
    image_out <- pFloatImageOutput  "Output fimage" 
    }; 
*/ 
/*----------------------------------------------------------------------
 v1.2 (04/2007): simplified header (LM)
 v1.3 (2013): portable version (GF)
----------------------------------------------------------------------*/

#include "mw3.h" 
#include "iio.h"
#include "stdio.h"
#include "stdlib.h"

extern void flst();
extern void flst_reconstruct();
 
/* This removes the shapes from the tree associated to pFloatImageInput 
that are too small (threshold *pMinArea). As a consequence all the remaining 
shapes of pFloatImageOutput are of area larger or equal than *pMinArea */ 

void mw_fgrain(int *pMinArea, Fimage pFloatImageInput, Fimage pFloatImageOutput) 
{ 
  int i; 
  Shapes pTree; 
 
  if(mw_change_fimage(pFloatImageOutput, pFloatImageInput->nrow, 
		      pFloatImageInput->ncol) == NULL) 
    mwerror(FATAL, 1, 
	    "fgrain --> Not enough memory to allocate the output image"); 
  if((pTree = mw_new_shapes()) == NULL) 
    mwerror(FATAL, 1, 
	    "fgrain --> Not enough memory to allocate the tree of shapes"); 

  /* Compute the Level Sets Transform of the input image */ 
  flst(NULL, pFloatImageInput, pTree, NULL, NULL); 
 
  /* Kill too small grains. 
     Bound i>0 because it is forbidden to delete the root, at index 0 */ 
  for(i = pTree->nb_shapes-1; i > 0; i--) 
    if(pTree->the_shapes[i].area < *pMinArea) 
      pTree->the_shapes[i].removed = (char)1; 
 
  /* Reconstruct in pFloatImageOutput the modified tree of shapes */ 
  flst_reconstruct(pTree, pFloatImageOutput); 
 
  mw_delete_shapes(pTree); 
} 

//  Main function and input/output.

Fimage fimageread(char* name)
{
      int nx,ny,nc;
         float *fdisp = iio_read_image_float_split(name, &nx, &ny, &nc);
         Fimage out = mw_change_fimage(NULL,ny,nx);
         free(out->gray);
         out->gray=fdisp;
         return out;
}

void fimagewrite(char* name, Fimage i)
{
      iio_save_image_float_split(name, i->gray, i->ncol, i->nrow, 1);
}


/*in and out must be allocated*/
void fgrain(int MinArea, float *in, int nx, int ny, float *out) {
   int i;
   Fimage mwin = mw_change_fimage(NULL,ny,nx);
   Fimage mwout = mw_new_fimage();
   for(i=0;i<nx*ny;i++) mwin->gray[i] = in[i]; 

   mw_fgrain( &MinArea, mwin, mwout);

   for(i=0;i<nx*ny;i++) out[i] = mwout->gray[i]; 
   mw_delete_fimage(mwin);
   mw_delete_fimage(mwout);
}


int main(int argc, char* argv[]) 
{
   // default parameters
   int min_area=20;
   if(argc<3) {
      fprintf(stderr, "Grain filter of an image\n");
      fprintf(stderr, "syntax: %s image_in image_out [min_area=20]\n", argv[0]);
      return 1;
   }
   if(argc>=4) min_area=atoi(argv[3]);
   Fimage in = fimageread(argv[1]);
   Fimage out = mw_change_fimage(NULL,in->nrow,in->ncol);
   fgrain(min_area, in->gray, in->ncol, in->nrow, out->gray); 
   fimagewrite(argv[2], out);
   return 0;
}
