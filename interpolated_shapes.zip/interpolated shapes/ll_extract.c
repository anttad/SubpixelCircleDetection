/*--------------------------- MegaWave2 Module -----------------------------*/
/* mwcommand 
 name = {ll_extract}; 
 version = {"1.3"}; 
 author = {"Lionel Moisan"}; 
 function = {"Compute the level lines of a Fimage"};
 usage = { 
   'l':levels->levels  "levels of quantization (Fsignal) (bilinear)",
   'o':offset->offset  "quantization offset (bilinear, default 0.5)",
   's':step->step      "quantization step (bilinear, default 1.0)",
   'p':[prec=5]->prec  "precision (# pts per unit length, bilinear case only)",
   'a':area->area      "minimum area (parameter for the grain filter)",
   't':tree->tree      "to use a previoulsy computed tree",
   'z'->z              "use zero order instead of bilinear interpolation",
   in->in              "input Fimage",
   out<-ll_extract     "computed level lines (output Flists)"
}; 
*/ 
/*----------------------------------------------------------------------
 v1.1: added missing area parameter (P.Monasse)
 v1.2: fixed max_size bug due to change in list.h (L.Moisan)
 v1.3 (04/2007): simplified header (LM)
----------------------------------------------------------------------*/

#include "mw3.h" 
#include "iio.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"



extern void flst_bilinear();
extern void flstb_quantize();
extern Flist flstb_boundary();
extern int fsaddles();




/* An elementary shape is a shape having a child of a different type. To keep consistency 
   between the tree and the associated image, it is forbidden to remove such a shape. This 
   function detects if pShape is an elementary shape, and if the answer is positive, mark 
   the shape to be its own gradation. */ 
void keep_elementary_shape(pShape) 
     Shape pShape; 
{ 
  Shape pChild; 
   
  /* If one of the sons is of different type, the object has only one shape */ 
  for(pChild = mw_get_first_child_shape(pShape); pChild != NULL; pChild = mw_get_next_sibling_shape(pChild)) 
    if(pChild->inferior_type != pShape->inferior_type) 
      break; 
 
  if(pChild != NULL) 
    pShape->data = (char*)1; 
} 




/* Find the gradation containg pShape, remove it but keep only one representative shape of 
   the gradation. 
   A gradation is defined to be a family of shapes such that: 
   One shape S and its child C are in the same gradation iff: 
   - C is the only child of S; 
   - C and S have the same type; 
   - the areas of C and S do not differ by a factor greater than fFactorIncreaseArea; 
   - C is not an elementary shape. 
   It is not hard to see that this relation induces a partition of the family of shapes, each 
   class of the partition is then called a gradation. 
   The representative shape of the gradation is the shape of the gradation with smallest L²/A, 
   where A is the area and L is the length of its boundary */ 
void remove_gradation(pShape, fFactorIncreaseArea, mincontrast, ref_tree) 
     Shape pShape; 
     Shapes ref_tree; 
     float fFactorIncreaseArea; 
     float mincontrast; 
{ 
  Shape pCurrentShape, pParent, pChild, pSibling, pRepresentativeShape; 
  float fCriterium, fOptimalCriterium, fMeanGrayLevel; 
 
  pCurrentShape = pRepresentativeShape = pShape; 
   
  /* 1) Go down the tree until the smallest shape in the gradation */ 
  pChild = mw_get_first_child_shape(pCurrentShape); 
  while(pChild != NULL && pChild->data == NULL && 
	pChild->inferior_type == pCurrentShape->inferior_type && 
	pChild->area * fFactorIncreaseArea >= pCurrentShape->area && 
	mw_get_next_sibling_shape(pChild) == NULL) 
    { 
      pCurrentShape = pChild; 
      pChild = mw_get_first_child_shape(pChild); 
    } 
  pChild = pCurrentShape; 
 
  /* 2) Go up the tree until the largest shape in the gradation */ 
  pParent = mw_get_parent_shape(pShape); 
  while(pParent != NULL && 
	pParent->inferior_type == pCurrentShape->inferior_type && 
	pParent->area <= pCurrentShape->area * fFactorIncreaseArea && 
	mw_get_first_child_shape(pParent) == pCurrentShape && 
	mw_get_next_sibling_shape(pCurrentShape) == NULL) 
    { 
      pCurrentShape = pParent; 
      pParent = mw_get_parent_shape(pParent); 
    } 


  // compute the mincontrast of this shape
  float contrast =  fabs(pChild->value - pParent->value);

   
  /* 3) Remove the gradation, keeping only the representative shape */ 
  fMeanGrayLevel = pChild->area * pChild->value; 
  fOptimalCriterium = (float)(pChild->boundary?pChild->boundary->size:0); 
  fOptimalCriterium *= fOptimalCriterium; 
  fOptimalCriterium /= (float)pChild->area; 
  pChild->data = (void*)1; 
  pChild->removed = (char)1; 
  pCurrentShape = mw_get_parent_shape(pChild); 
  while(pCurrentShape != pParent) 
    { 
      fMeanGrayLevel += (pCurrentShape->area - pChild->area) * pCurrentShape->value; 
      fCriterium = (float)(pCurrentShape->boundary?pCurrentShape->boundary->size:0);
      fCriterium *= fCriterium; 
      fCriterium /= (float)pCurrentShape->area; 
      if(fCriterium < fOptimalCriterium) 
	  { 
	    fOptimalCriterium = fCriterium; 
	    pRepresentativeShape = pCurrentShape; 
	  } 
      pChild = pCurrentShape; 
      pCurrentShape = mw_get_parent_shape(pCurrentShape); 
      pChild->removed = (char)1; 
      pChild->data = (void*)1; 
    } 
  pRepresentativeShape->removed = 0; 
//  pRepresentativeShape->value = fMeanGrayLevel / pChild->area; 


  if (contrast < mincontrast) { 
     pRepresentativeShape->removed = 1; 
  }
  else{

//     Flist boundary;
//      boundary = mw_change_flist(NULL,2,0,2);
////ls = mw_change_flists(NULL,ref_tree->nb_shapes-1,0);
////
//      	flst_boundary(ref_tree,pRepresentativeShape,boundary);
//
//
//     printf("Shape of length: %d\n", boundary->size);
//     for(int i=0; i<boundary->size; i++) {
//        printf("%f %f\n", ((float*)boundary->values)[2*i], ((float*)boundary->values)[2*i+1]);
//     }
//

  }



} 








Flists ll_extract(in,levels,offset,step,prec,area,tree,z, mincontrast, pPercentIncreaseArea, pFloatImageOutput)
     Fimage in, pFloatImageOutput;
     Fsignal levels;
     float *offset,*step;
     int *area,*prec;
     Shapes tree;
     char *z;
   float pPercentIncreaseArea;
   float mincontrast;
{
  Flists ls;
  Flist boundary;
  Shapes ref_tree;
  Shape s;
  Fimage saddles,copy_in;
  int newtree=0,i;
  float **tabsaddles;

  /* check consistency */
  if (tree) {
    if (z && tree->interpolation!=0)
      mwerror(FATAL,1,"Please use a zero order tree with -z option\n");
    if (!z && tree->interpolation!=1)
      mwerror(FATAL,1,"Please use a bilinear tree without -z option\n");
  }
  if (z && (step || levels))
    mwerror(WARNING,0,"-s and -l options have no effect with -z option\n");

  /* compute FLST if needed */
  if (!tree) {
    newtree = 1;
    tree = mw_new_shapes();
    copy_in = mw_change_fimage(NULL,in->nrow,in->ncol);
    if (!tree || !copy_in) mwerror(FATAL,1,"Not enough memory");
    mw_copy_fimage(in,copy_in);
    if (z) 
      flst(area,copy_in,tree);
    else
      flst_bilinear(area,copy_in,tree);
    mw_delete_fimage(copy_in);
  } 

  if (!z) {
    /* bilinear case : compute saddle points and quantize FLST tree */
    ref_tree = mw_new_shapes();
    saddles = mw_new_fimage();
    if (!ref_tree || !saddles) mwerror(FATAL,1,"Not enough memory");
    fsaddles(in,saddles);
    tabsaddles = mw_newtab_gray_fimage(saddles);
    if (!tabsaddles) mwerror(FATAL,1,"Not enough memory");
    flstb_quantize(levels,offset,step,tree,ref_tree);
    if (newtree) mw_delete_shapes(tree);
  } else ref_tree = tree;
  mwdebug("Total number of shapes: %d\n",ref_tree->nb_shapes);




  /* First find the shapes whose containing gradation is reduced to the shape itself */ 
  for(i = ref_tree->nb_shapes-1; i > 0; i--) 
    keep_elementary_shape(&ref_tree->the_shapes[i]); 



  /* Kill gradations. 
     We use the field data of a shape to track the shapes which were already dealt with */ 
//   float pPercentIncreaseArea=20;
//   float mincontrast=10;
   float fFactorIncreaseArea = (float)(1.0 + 0.01 * pPercentIncreaseArea);


  for(i = ref_tree->nb_shapes-1; i > 0; i--) 
    if(ref_tree->the_shapes[i].data == NULL) 
      remove_gradation(&ref_tree->the_shapes[i], fFactorIncreaseArea, mincontrast, ref_tree); 





  /* allocate memory */
  boundary = mw_change_flist(NULL,2,0,2);
  ls = mw_change_flists(NULL,ref_tree->nb_shapes-1,0);
  if (!ls) mwerror(FATAL,1,"Not enough memory\n");
  
  /* MAIN LOOP : extract boundaries */
  for (i=0,ls->size=0;i<ref_tree->nb_shapes;i++) {
     s = &ref_tree->the_shapes[i];
     if (!s->removed) {
     if (s->parent) {
        if (z)
           flst_boundary(ref_tree,s,boundary);
        else 
           flstb_boundary(prec,in,ref_tree,s,NULL,boundary,tabsaddles);
        ls->list[ls->size++] = mw_copy_flist(boundary,NULL);
     }
     } 
  }
  
  /* Reconstruct in pFloatImageOutput the modified tree of shapes */ 
  flst_reconstruct(ref_tree, pFloatImageOutput); 


  /* free memory and exit */
  mw_delete_flist(boundary);
  if (!z) {
    free(tabsaddles);
    mw_delete_fimage(saddles);
    mw_delete_shapes(ref_tree);
  }
  mwdebug("%d boundaries written (alloc %d)\n",ls->size,ls->max_size);

  return(ls);
}


//  Main function and input/output.

Fimage fimageread(char* name)
{
      int nx,ny,nc;
         float *fdisp = iio_read_image_float_split(name, &nx, &ny, &nc);
         Fimage out = mw_change_fimage(NULL,ny,nx);
         free(out->gray);
         out->gray=fdisp;
         return out;
}

void fimagewrite(char* name, Fimage i)
{
      iio_save_image_float_split(name, i->gray, i->ncol, i->nrow, 1);
}


// c: pointer to original argc
// v: pointer to original argv
// o: option name after hyphen
// d: default value (if NULL, the option takes no argument)
static char *pick_option(int *c, char ***v, char *o, char *d)
{
    int argc = *c;
    char **argv = *v;
    int id = d ? 1 : 0;
    for (int i = 0; i < argc - id; i++)
        if (argv[i][0] == '-' && 0 == strcmp(argv[i] + 1, o)) {
            char *r = argv[i + id] + 1 - id;
            *c -= id + 1;
            for (int j = i; j < argc - id; j++)
                (*v)[j] = (*v)[j + id + 1];
            return r;
        }
    return d;
}





void write_fsignal(char *name, Fsignal sig) {
   FILE *f;

   f=fopen(name, "w");
   fprintf(f,"signal %d\n",sig->size);
   for (int j = 0 ; j < sig->size; j++) {
      fprintf(f,"%f\n",sig->values[j]);
   }
   fclose(f);
}


Fsignal read_fsignal(char *name) {
   FILE *f;
   int num;
   float val;

   f=fopen(name, "r");

   fscanf(f,"signal %d\n",&num);

   Fsignal sig =mw_new_fsignal();
   sig = mw_alloc_fsignal(sig, num);

   for (int j = 0 ; j < num; j++) {
      fscanf(f,"%f",&val);
      sig->values[j] = val;
   }

   fclose(f);
   return sig;

}



int main(int argc, char* argv[]) 
{
   // default parameters
   float offset = atof(pick_option(&argc, &argv, (char*) "l", (char*) "0.5"));
   float step = atof(pick_option(&argc, &argv, (char*) "s", (char*) "1.0"));
   int prec = atoi(pick_option(&argc, &argv, (char*) "p", (char*) "5"));
   int area = atoi(pick_option(&argc, &argv, (char*) "a", (char*) "0"));
   char *z = pick_option(&argc, &argv, (char*) "z", NULL);

   if(argc<2) {
      fprintf(stderr, "Sharpen an image (select some of the parallel level lines)\n");
      fprintf(stderr, "syntax: %s image_in image_out [percent_increase_area=20 (1...1000) mincontrast=20] [-o offset (0.5)] [-s step (1.0)] [-z (do not interpolate if set)] \n", argv[0]);
      return 1;
   }

   float mincontrast, pPercentIncreaseArea;
   if(argc>=4) pPercentIncreaseArea= (float)atof(argv[3]);
   if(argc>=5) mincontrast= (float)atof(argv[4]);

   Fimage in = fimageread(argv[1]);
   Fimage out = mw_change_fimage(NULL,in->nrow,in->ncol);

   Flists ls = ll_extract(in,NULL,&offset,&step,&prec,NULL,NULL,z, mincontrast, pPercentIncreaseArea, out);

   for (int i=0;i<ls->size;i++) {
      printf("# Shape of length: %d\n", ls->list[i]->size );
      for (int j=0;j<ls->list[i]->size ;j++) {
         printf("%f %f\n",  ls->list[i]->values[2*j], ls->list[i]->values[2*j+1]);

      }

  }

   fimagewrite(argv[2], out);
   return 0;
}
