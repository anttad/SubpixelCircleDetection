/*
 * libmw.h
 */

#ifndef _LIBMW_H_
#define _LIBMW_H_

/* src/libmw.c */

#endif /* !_LIBMW_H_ */
