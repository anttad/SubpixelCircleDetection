#extract interpolated "sharp" contours 
# 

./ll_extract test_image.tif  out.tif  2 10 -p 5 -s .5 > courves.txt
echo "plot 'courves.txt' with lines" | gnuplot -p


