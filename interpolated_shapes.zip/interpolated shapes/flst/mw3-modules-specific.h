/* src/image/level_lines/flstb_dualchain.c */
void flstb_dualchain(Shapes pTree, Shape pShape, Flist pBoundary,
                     char *ctabtabSaddleValues);
/* src/image/level_lines/flst_reconstruct.c */
void flst_reconstruct(Shapes pTree, Fimage pFloatImageOutput);
/* src/image/level_lines/fsaddles.c */
int fsaddles(Fimage pImage, Fimage pSaddlesImage);
/* src/image/level_lines/flst_pixels.c */
void flst_pixels(Shapes pTree);

